// ============================================================
// SUNO WAV BULK DOWNLOADER - Console Script
// ============================================================
//
// USAGE:
//   1. Go to https://suno.com/me (your Library)
//   2. Open browser DevTools (F12 or Cmd+Shift+I)
//   3. Paste this entire script into the Console tab
//   4. Press Enter — it will enumerate all your songs, then
//      trigger WAV conversion and download each one.
//
// CONFIGURATION (edit these before running):
const CONFIG = {
  // Delay between songs (ms) — ~10s mimics human download pace
  CONVERSION_DELAY: 8000,
  // Delay between page fetches when enumerating library (ms)
  PAGE_FETCH_DELAY: 3000,
  // Delay before first WAV download attempt after conversion (ms)
  WAV_READY_DELAY: 6000,
  // Max retries for WAV download (conversion can take time)
  WAV_MAX_RETRIES: 8,
  // Delay between WAV download retries (ms)
  WAV_RETRY_DELAY: 6000,
  // Set to true to do a dry run (list songs without downloading)
  DRY_RUN: false,
  // Max songs to download (set to Infinity for all)
  MAX_SONGS: Infinity,
  // Skip songs with these statuses
  SKIP_STATUSES: ['trashed', 'error', 'failed'],
};

// ============================================================
// HELPERS
// ============================================================

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function sanitizeFilename(name) {
  return name.replace(/[\/\\:*?"<>|]/g, '_').replace(/\s+/g, ' ').trim();
}

function formatBytes(bytes) {
  if (!bytes) return 'unknown size';
  const mb = (bytes / (1024 * 1024)).toFixed(1);
  return `${mb} MB`;
}

function log(msg, type = 'info') {
  const prefix = {
    info: '🎵',
    success: '✅',
    warn: '⚠️',
    error: '❌',
    progress: '⏳',
  }[type] || 'ℹ️';
  console.log(`${prefix} [Suno WAV Downloader] ${msg}`);
}

// ============================================================
// AUTH
// ============================================================

async function getAuthToken() {
  try {
    if (window.Clerk?.session) {
      const token = await window.Clerk.session.getToken();
      if (token) return token;
    }
  } catch (e) {
    log('Clerk token failed, trying cookie fallback...', 'warn');
  }
  const cookie = document.cookie
    .split('; ')
    .find((c) => c.startsWith('__session='));
  if (cookie) return cookie.split('=')[1];
  throw new Error('Could not get auth token. Are you logged in to Suno?');
}

// ============================================================
// API: LIST ALL SONGS
// ============================================================

async function fetchAllSongs(token) {
  const songs = [];
  let cursor = null;
  let hasMore = true;
  let page = 0;

  log('Fetching your song library...', 'progress');

  while (hasMore) {
    const body = cursor ? { page: 1, cursor } : { page: 1 };

    const resp = await fetch('https://studio-api.prod.suno.com/api/feed/v3', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (resp.status === 429) {
      log('Rate limited — waiting 10s before retrying...', 'warn');
      await sleep(10000);
      continue; // retry same page
    }

    if (!resp.ok) {
      throw new Error(`Feed API error: ${resp.status} ${resp.statusText}`);
    }

    const data = await resp.json();
    const clips = data.clips || [];

    for (const clip of clips) {
      if (CONFIG.SKIP_STATUSES.includes(clip.status)) continue;
      songs.push({
        id: clip.id,
        title: clip.title || 'Untitled',
        status: clip.status,
        created_at: clip.created_at,
        audio_url: clip.audio_url,
      });
    }

    hasMore = data.has_more;
    cursor = data.next_cursor;
    page++;
    log(`  Page ${page}: found ${clips.length} clips (${songs.length} total so far)`, 'info');

    if (hasMore) await sleep(CONFIG.PAGE_FETCH_DELAY);
  }

  log(`Found ${songs.length} songs in your library.`, 'success');
  return songs;
}

// ============================================================
// API: TRIGGER WAV CONVERSION
// ============================================================

async function triggerWavConversion(token, songId) {
  const resp = await fetch(
    `https://studio-api.prod.suno.com/api/gen/${songId}/convert_wav/`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    }
  );

  if (resp.status === 204 || resp.status === 200) return true;
  if (resp.status === 429) {
    log('Rate limited on conversion — waiting 15s...', 'warn');
    await sleep(15000);
    return triggerWavConversion(token, songId); // retry
  }
  log(`Conversion trigger failed for ${songId}: ${resp.status}`, 'error');
  return false;
}

// ============================================================
// DOWNLOAD: WAV FILE
// ============================================================

async function downloadWav(songId, title, index, total) {
  const wavUrl = `https://cdn1.suno.ai/${songId}.wav`;
  const filename = `${sanitizeFilename(title)} [${songId.slice(0, 8)}].wav`;

  for (let attempt = 1; attempt <= CONFIG.WAV_MAX_RETRIES; attempt++) {
    try {
      const resp = await fetch(wavUrl, { method: 'HEAD' });

      if (resp.status === 200) {
        const size = resp.headers.get('content-length');
        log(`  Downloading: ${filename} (${formatBytes(size)})`, 'progress');

        // Trigger actual download via hidden link
        const blobResp = await fetch(wavUrl);
        const blob = await blobResp.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        log(`  [${index + 1}/${total}] Downloaded: ${filename}`, 'success');
        return true;
      }

      if (resp.status === 404 && attempt < CONFIG.WAV_MAX_RETRIES) {
        log(
          `  WAV not ready yet (attempt ${attempt}/${CONFIG.WAV_MAX_RETRIES}), waiting...`,
          'progress'
        );
        await sleep(CONFIG.WAV_RETRY_DELAY);
        continue;
      }
    } catch (e) {
      if (attempt < CONFIG.WAV_MAX_RETRIES) {
        log(`  Download error (attempt ${attempt}), retrying...`, 'warn');
        await sleep(CONFIG.WAV_RETRY_DELAY);
        continue;
      }
    }
  }

  log(`  Failed to download WAV for: ${title} (${songId})`, 'error');
  return false;
}

// ============================================================
// MAIN
// ============================================================

(async () => {
  try {
    console.clear();
    log('=== SUNO WAV BULK DOWNLOADER ===', 'info');
    log(`Config: delay=${CONFIG.CONVERSION_DELAY}ms, retries=${CONFIG.WAV_MAX_RETRIES}, dry_run=${CONFIG.DRY_RUN}`, 'info');

    // Step 1: Auth
    const token = await getAuthToken();
    log('Authenticated successfully.', 'success');

    // Step 2: Fetch all songs
    const allSongs = await fetchAllSongs(token);

    if (allSongs.length === 0) {
      log('No songs found in your library!', 'warn');
      return;
    }

    // Apply max limit
    const songs = allSongs.slice(0, CONFIG.MAX_SONGS);
    log(`Will process ${songs.length} songs.`, 'info');

    // Dry run — just list
    if (CONFIG.DRY_RUN) {
      log('--- DRY RUN: Song List ---', 'info');
      songs.forEach((s, i) => {
        console.log(`  ${i + 1}. ${s.title} [${s.id}] (${s.status})`);
      });
      log(`Total: ${songs.length} songs. Set DRY_RUN to false to download.`, 'info');
      return;
    }

    // Step 3: Process each song
    const results = { success: 0, failed: 0, skipped: 0 };

    for (let i = 0; i < songs.length; i++) {
      const song = songs[i];
      log(`[${i + 1}/${songs.length}] Processing: ${song.title}`, 'progress');

      // Trigger WAV conversion
      const converted = await triggerWavConversion(token, song.id);
      if (!converted) {
        results.failed++;
        continue;
      }

      // Wait for conversion to complete
      await sleep(CONFIG.WAV_READY_DELAY);

      // Download
      const downloaded = await downloadWav(song.id, song.title, i, songs.length);
      if (downloaded) {
        results.success++;
      } else {
        results.failed++;
      }

      // Delay before next song
      if (i < songs.length - 1) {
        await sleep(CONFIG.CONVERSION_DELAY);
      }
    }

    // Summary
    log('=== DOWNLOAD COMPLETE ===', 'success');
    log(`  ✅ Success: ${results.success}`, 'info');
    log(`  ❌ Failed:  ${results.failed}`, 'info');
    log(`  ⏭️  Skipped: ${results.skipped}`, 'info');

  } catch (e) {
    log(`Fatal error: ${e.message}`, 'error');
    console.error(e);
  }
})();
